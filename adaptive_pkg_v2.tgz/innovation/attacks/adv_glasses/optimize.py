"""
optimize.py – optimise the texture of a printed eyeglass frame.

    # impersonation: the attacker's frames should match the victim, top-1 in the class
    python -m innovation.attacks.adv_glasses.optimize \\
        --attacker-frames data/innovation/frames/owner --gallery data/innovation/gallery \\
        --attacker-id owner --victim VOX_id10270 --mode impersonate \\
        --color-map data/innovation/chart/colormap.json --steps 1500 --device cuda

    # dodging: the attacker should no longer match themself
    python -m innovation.attacks.adv_glasses.optimize ... --mode dodge

Inputs
- --attacker-frames: frames captured in the Lab (<person>/<session>/*.jpg). With two
  or more sessions the last one (or --eval-sessions) is held out for evaluation;
  with one session 30% of frames are held out at random.
- --gallery: one folder per enrolled identity (victim, attacker, the simulated class),
  embedded through the backend path. The attacker must be in it (plan_L1.md §2).

The texture T lives in print colours. Each step: T -> M(T) (what the camera sees)
-> placed on the eyes by FaceMesh with placement jitter -> composited on the
crop -> light, blur, distance and JPEG (EOT) -> the recogniser. T itself is
the file to print. Outputs go to results/innovation/<run>/.
"""
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F

from innovation.attacks.adv_glasses import eot, faces, glasses, pipeline, printability
from innovation.eval.runs import new_run, write_json

TEX_H, TEX_W = 15, 40           # default parameter resolution; upsampled bicubic to 150 x 400 template


def upsample_logits(logits: torch.Tensor, out_h: int = glasses.TEMPLATE_H, out_w: int = glasses.TEMPLATE_W) -> torch.Tensor:
    """Upsample parameter logits to template resolution using bicubic interpolation."""
    if logits.shape[-2:] == (out_h, out_w):
        return logits
    if logits.dim() == 3:
        return F.interpolate(logits[None], size=(out_h, out_w), mode="bicubic", align_corners=False)[0]
    return F.interpolate(logits, size=(out_h, out_w), mode="bicubic", align_corners=False)


CONTROL_SEED = 0


def permute_cells(logits: torch.Tensor, seed: int = CONTROL_SEED) -> torch.Tensor:
    """Randomly permute spatial cells (H x W) of logits at parameter resolution,
    preserving the 3 channels of each cell.
    Works for (3, H, W) or (B, 3, H, W).
    """
    squeeze = False
    if logits.dim() == 4:
        logits = logits[0]
        squeeze = True
    c, h, w = logits.shape
    rng = np.random.default_rng(seed)
    perm = torch.from_numpy(rng.permutation(h * w)).to(logits.device)
    flat = logits.reshape(c, h * w)
    shuffled = flat[:, perm].reshape(c, h, w)
    return shuffled[None] if squeeze else shuffled


def control_random_texture(logits: torch.Tensor, seed: int = CONTROL_SEED,
                           out_h: int = glasses.TEMPLATE_H,
                           out_w: int = glasses.TEMPLATE_W) -> torch.Tensor:
    """Generate control_random print texture:
    Randomly permute spatial cells (H x W) of logits at parameter resolution (preserving 3 channels per cell),
    then upsample bicubic to (out_h, out_w) and apply sigmoid, exactly like the real texture.
    Returns T in print colours with shape (3, out_h, out_w) in [0, 1].
    """
    shuffled_logits = permute_cells(logits, seed=seed)
    logits_full = upsample_logits(shuffled_logits, out_h=out_h, out_w=out_w)
    return torch.sigmoid(logits_full)


make_control_random = control_random_texture


# ── frames and split ────────────────────────────────────────────────────────

def sort_session_frames_by_time(session_folder: Path, fs: list[Path]) -> list[Path]:
    """Sort session frames by timestamp in meta.csv if available, else numeric stem or filename."""
    meta_path = session_folder / "meta.csv"
    ms: dict[int, float] = {}
    if meta_path.exists():
        try:
            with open(meta_path, encoding="utf-8") as fh:
                for row in csv.DictReader(fh):
                    if "index" in row and "client_ms" in row:
                        ms[int(row["index"])] = float(row["client_ms"])
        except Exception:
            pass

    def sort_key(p: Path):
        try:
            idx = int(p.stem)
            return (0, ms.get(idx, float(idx)))
        except ValueError:
            return (1, p.name)

    return sorted(fs, key=sort_key)


def split_frames(root: Path, eval_sessions: list[str] | None, seed: int, dev_frac: float = 0.0,
                 dev_mode: str = "random") -> tuple[list[Path], list[Path], dict]:
    sessions = sorted(p for p in Path(root).iterdir() if p.is_dir())
    if not sessions:  # a flat folder of frames
        sessions = [Path(root)]
    by = {s.name: faces.list_images(s) for s in sessions}
    if eval_sessions:
        missing = sorted(set(eval_sessions) - set(by))
        if missing:
            raise SystemExit(f"eval session(s) not found in {root}: {', '.join(missing)}")
    if len(by) >= 2 or eval_sessions:
        if eval_sessions is not None:
            held = set(eval_sessions)
        else:
            held = {sorted(by)[-1]}
        train = [f for s, fs in by.items() if s not in held for f in fs]
        test = [f for s, fs in by.items() if s in held for f in fs]
        how = f"held-out sessions: {sorted(held)}"
        is_multi_session = True
    else:
        held = set()
        fs = list(next(iter(by.values())))
        rng = np.random.default_rng(seed)
        rng.shuffle(fs)
        k = int(round(len(fs) * 0.7))
        train, test, how = sorted(fs[:k]), sorted(fs[k:]), "single session, random 70/30"
        is_multi_session = False

    dev: list[Path] = []
    if dev_frac > 0:
        if dev_mode == "block":
            if is_multi_session:
                train_sessions = [s for s in sessions if s.name not in held]
                dev_collected: list[Path] = []
                train_collected: list[Path] = []
                for s in train_sessions:
                    fs = by[s.name]
                    fs_sorted = sort_session_frames_by_time(s, fs)
                    k_dev = int(round(len(fs_sorted) * dev_frac))
                    if k_dev > 0:
                        dev_collected.extend(fs_sorted[-k_dev:])
                        train_collected.extend(fs_sorted[:-k_dev])
                    else:
                        train_collected.extend(fs_sorted)
                dev = dev_collected
                train = train_collected
            else:
                train_sorted = sort_session_frames_by_time(sessions[0], train)
                k_dev = int(round(len(train_sorted) * dev_frac))
                dev = train_sorted[-k_dev:] if k_dev > 0 else []
                train = train_sorted[:-k_dev] if k_dev > 0 else train_sorted
        else:
            rng_dev = np.random.default_rng(seed)
            train_list = list(train)
            perm = rng_dev.permutation(len(train_list))
            k_dev = int(round(len(train_list) * dev_frac))
            dev_set = {train_list[i] for i in perm[:k_dev]}
            dev = sorted([f for f in train_list if f in dev_set])
            train = sorted([f for f in train_list if f not in dev_set])

    split_dict = {
        "how": how,
        "sessions": {s: len(fs) for s, fs in by.items()},
        "train": [str(f) for f in train],
        "eval": [str(f) for f in test],
        "dev_mode": dev_mode,
    }
    if dev_frac > 0:
        split_dict["dev"] = [str(f) for f in dev]
        split_dict["train"] = [str(f) for f in train]
        split_dict["how"] += f", dev fraction {dev_frac:.2f} ({len(dev)} frames, mode={dev_mode})"

    return train, test, split_dict


def prepare(frames: list[Path], detector, eyes_finder) -> tuple[list[dict], dict]:
    """Detection, crop window, eye placement and enhancer check for each frame."""
    items, report = [], {"no_face": 0, "no_mesh": 0, "enhancer_applied": 0}
    for f in frames:
        img = cv2.imread(str(f))
        bbox = detector.detect(img) if img is not None else None
        if bbox is None:
            report["no_face"] += 1
            continue
        _, meta = faces.enhance(faces.crop(img, bbox))
        if meta and meta.get("applied"):
            report["enhancer_applied"] += 1        # plan_L1 §3: optimise only on normal light
            continue
        eyes = eyes_finder.eyes(img)
        if eyes is None:
            report["no_mesh"] += 1
            continue
        win = faces.crop_window(bbox, img.shape)
        x0, y0, x1, y1 = win
        items.append({"file": str(f), "window": win, "A": glasses.similarity(eyes),
                      "region": pipeline.to_tensor(img[y0:y1, x0:x1])})
    report["used"] = len(items)
    return items, report


# ── losses ──────────────────────────────────────────────────────────────────

def soft_max_cos(emb: torch.Tensor, E: torch.Tensor, tau: float) -> torch.Tensor:
    """Smooth version of find_match's max over one identity's enrolled images.

    The softmax-weighted mean sum_i softmax(cos/tau)_i * cos_i: never above the
    true max (so never above 1), tends to it as tau -> 0, and has no log(n) term,
    so identities are not shifted by how many images they have (the earlier
    tau * (logsumexp - log n) moved an identity with 10 images by tau*log 10 =
    0.115 against tau*log 5 = 0.080 for one with 5, a 0.035 bias in the margin).
    Galleries also hold 5 images per identity (faces.GALLERY_PER_ID).
    """
    cos = emb @ E.T
    return (torch.softmax(cos / tau, dim=1) * cos).sum(dim=1)


def tv(t: torch.Tensor) -> torch.Tensor:
    return (t[:, 1:, :] - t[:, :-1, :]).abs().mean() + (t[:, :, 1:] - t[:, :, :-1]).abs().mean()


# ── main ────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--attacker-frames", required=True)
    ap.add_argument("--gallery", required=True)
    ap.add_argument("--extra-gallery", nargs="*", default=None,
                    help="extra gallery directory/directories to merge into main gallery")
    ap.add_argument("--attacker-id", required=True, help="the attacker's folder name in the gallery")
    ap.add_argument("--victim", help="the victim's folder name in the gallery (impersonate)")
    ap.add_argument("--mode", choices=("impersonate", "dodge"), default="impersonate")
    ap.add_argument("--checkpoint", default="checkpoints/method3_best.pth")
    ap.add_argument("--color-map", help="colormap.json from printability fit; identity when omitted")
    ap.add_argument("--chart", help="chart.json, for the NPS palette (default: the standard chart colours)")
    ap.add_argument("--thickness", type=float, default=35.0)
    ap.add_argument("--rim-scale", type=float, default=1.1)
    ap.add_argument("--frame-mask", help="path to template mask PNG for PhotoFrame (overrides --thickness/--rim-scale)")
    ap.add_argument("--frame-lens", help="path to lens region PNG to preserve holes during dilation")
    ap.add_argument("--grow-px", type=float, default=0.0,
                    help="outward dilation in template pixels for PhotoFrame (default: 0.0)")
    ap.add_argument("--clearance-mm", type=float, default=0.0,
                    help="pupil clearance radius in mm for PhotoFrame fill-lens mode (default: 0.0 = outward only)")
    ap.add_argument("--ipd-mm", type=float, default=63.0,
                    help="interpupillary distance in mm for PhotoFrame clearance scaling (default: 63.0)")
    ap.add_argument("--tex-res", type=int, nargs=2, default=[15, 40], metavar=("H", "W"),
                    help="parameter grid resolution (H, W); upsampled bicubic to 150x400 (default: 15 40)")
    ap.add_argument("--steps", type=int, default=1500)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--lr", type=float, default=0.01)
    ap.add_argument("--tau", type=float, default=0.05)
    ap.add_argument("--margin", type=float, default=0.05)
    ap.add_argument("--lambda-tv", type=float, default=2.5)
    ap.add_argument("--lambda-nps", type=float, default=0.5)
    ap.add_argument("--eval-sessions", nargs="*")
    ap.add_argument("--dev-frac", type=float, default=0.0,
                    help="fraction of training frames held out for dev validation (default: 0.0)")
    ap.add_argument("--dev-mode", choices=("random", "block"), default="random",
                    help="how to split dev frames: 'random' (default) or 'block' (last continuous chunk per session)")
    ap.add_argument("--no-eot", action="store_true",
                    help="disable EOT during optimization (no jitter, no photometric transforms)")
    ap.add_argument("--max-gallery", type=int, default=faces.GALLERY_PER_ID,
                    help="images per identity in the gallery (5 = the 5 Register angles)")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--log-every", type=int, default=25)
    args = ap.parse_args()
    if args.mode == "impersonate" and not args.victim:
        ap.error("--victim is required for impersonation")

    torch.manual_seed(args.seed)
    rng = np.random.default_rng(args.seed)
    from backend.face_recognizer import FaceRecognizer
    recognizer = FaceRecognizer(ckpt_path=args.checkpoint, strict=True)   # stops on missing/unexpected keys
    pipe = pipeline.TorchPipeline(recognizer, args.device)
    detector, eyes_finder = faces.FaceDetector(), faces.EyeLandmarks()

    run = new_run(f"advglasses_{args.mode}", vars(args))
    gallery, g_report = faces.build_gallery(Path(args.gallery), recognizer, detector, args.max_gallery,
                                            cache_dir=run.parent / "_cache")
    if g_report.get("uneven"):
        print(f"WARNING: fewer than {args.max_gallery} usable images for {g_report['uneven']}")

    extra_gallery_report = {}
    extra_gallery_list = [str(p) for p in args.extra_gallery] if args.extra_gallery else []
    if args.extra_gallery:
        for eg_path in args.extra_gallery:
            eg_dir = Path(eg_path)
            if not eg_dir.exists():
                raise SystemExit(f"extra gallery directory not found: {eg_dir}")
            eg_gal, eg_rep = faces.build_gallery(eg_dir, recognizer, detector, args.max_gallery,
                                                cache_dir=run.parent / "_cache")
            duplicates = set(gallery.embeddings.keys()) & set(eg_gal.embeddings.keys())
            if duplicates:
                raise SystemExit(f"Duplicate identities found when merging extra gallery: {sorted(duplicates)}")
            gallery.embeddings.update(eg_gal.embeddings)
            extra_gallery_report[str(eg_path)] = eg_rep

    if args.attacker_id not in gallery.embeddings:
        raise SystemExit(f"attacker '{args.attacker_id}' has no usable images in the gallery")
    if args.mode == "impersonate" and args.victim not in gallery.embeddings:
        raise SystemExit(f"victim '{args.victim}' has no usable images in the gallery")

    train_files, _, split = split_frames(Path(args.attacker_frames), args.eval_sessions, args.seed,
                                         args.dev_frac, args.dev_mode)
    items, p_report = prepare(train_files, detector, eyes_finder)
    if len(items) < 4:
        raise SystemExit(f"only {len(items)} usable training frames: {p_report}")

    E = {k: torch.from_numpy(v).float().to(args.device) for k, v in gallery.embeddings.items()}
    target = args.victim if args.mode == "impersonate" else args.attacker_id
    others = [k for k in E if k != target]

    if args.frame_mask:
        shape = glasses.PhotoFrame(args.frame_mask, args.frame_lens, args.grow_px, args.clearance_mm, args.ipd_mm)
    else:
        shape = glasses.FrameShape(args.thickness, args.rim_scale)
    mask = torch.from_numpy(shape.mask())[None].to(args.device)
    cover = [glasses.coverage(mask.cpu(), it["A"], it["window"]) for it in items]
    cmap = printability.ColorMap.load(Path(args.color_map)) if args.color_map else printability.ColorMap.identity()
    palette = torch.tensor(json.loads(Path(args.chart).read_text())["colours_rgb"] if args.chart
                           else printability.chart_colours(), dtype=torch.float32, device=args.device)

    tex_h, tex_w = args.tex_res[0], args.tex_res[1]
    logits = (0.05 * torch.randn(3, tex_h, tex_w, device=args.device)).requires_grad_(True)
    opt = torch.optim.Adam([logits], lr=args.lr)
    log_rows, t0 = [], time.time()

    for step in range(1, args.steps + 1):
        logits_full = upsample_logits(logits)
        T = torch.sigmoid(logits_full)                  # print colours
        seen = cmap(T)                                  # what the camera sees
        batch = [items[i] for i in rng.choice(len(items), size=min(args.batch, len(items)), replace=False)]
        crops = []
        for it in batch:
            if args.no_eot:
                A = it["A"]
                out = glasses.render(it["region"].to(args.device), seen, mask, A, it["window"])
                crops.append(out)
            else:
                A = glasses.jitter(it["A"], eot.TRAIN.shift_px, eot.TRAIN.rot_deg, eot.TRAIN.scale, rng)
                out = glasses.render(it["region"].to(args.device), seen, mask, A, it["window"])
                crops.append(eot.photometric(out, eot.TRAIN, rng))
        emb = pipe.embed(crops)

        s_target = soft_max_cos(emb, E[target], args.tau)
        s_others = torch.stack([soft_max_cos(emb, E[k], args.tau) for k in others], dim=1) if others else None
        if args.mode == "impersonate":
            l_main = (1 - s_target).mean()
            l_margin = F.relu(s_others - s_target[:, None] + args.margin).sum(1).mean() if others else torch.zeros(())
            l_margin_att = F.relu(s_others[:, others.index(args.attacker_id)] - s_target + args.margin).mean()
        else:
            l_main = s_target.mean()
            l_margin = l_margin_att = torch.zeros((), device=args.device)
        l_tv, l_nps = tv(T), printability.nps(T, palette)
        loss = l_main + l_margin + args.lambda_tv * l_tv + args.lambda_nps * l_nps
        opt.zero_grad()
        loss.backward()
        opt.step()

        if step % args.log_every == 0 or step == 1 or step == args.steps:
            with torch.no_grad():
                hard = {k: (emb @ E[k].T).max(1).values for k in E}
                best = torch.stack([hard[k] for k in sorted(E)], 1).max(1)
                top_ids = [sorted(E)[i] for i in best.indices.tolist()]
                if args.mode == "impersonate":
                    ok = [(t == target and v >= 0.5) for t, v in zip(top_ids, best.values.tolist())]
                else:
                    ok = [not (t == target and v >= 0.5) for t, v in zip(top_ids, best.values.tolist())]
            row = {"step": step, "loss": float(loss), "main": float(l_main), "margin": float(l_margin),
                   "margin_vs_attacker": float(l_margin_att), "tv": float(l_tv), "nps": float(l_nps),
                   "target_cos": float(hard[target].mean()), "batch_success": float(np.mean(ok)),
                   "seconds": round(time.time() - t0, 1)}
            log_rows.append(row)
            print(" ".join(f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()), flush=True)

    with open(run / "loss.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(log_rows[0]))
        w.writeheader(); w.writerows(log_rows)

    logits_full = upsample_logits(logits)
    T = torch.sigmoid(logits_full).detach().cpu()
    tex_bgr = (T.flip(0).permute(1, 2, 0).numpy() * 255).round().astype(np.uint8)
    cv2.imwrite(str(run / "texture_print.png"), tex_bgr)              # print colours: the file to print
    cv2.imwrite(str(run / "mask.png"), (shape.mask() * 255).astype(np.uint8))
    if args.frame_mask:
        shape_dict = {
            "frame_source": "photo",
            "frame_mask": str(args.frame_mask),
            "frame_lens": str(args.frame_lens) if args.frame_lens else None,
            "grow_px": float(args.grow_px),
            "clearance_mm": float(args.clearance_mm),
            "ipd_mm": float(args.ipd_mm),
        }
    else:
        shape_dict = vars(shape)
    torch.save({"logits": logits.detach().cpu(), "shape": shape_dict, "tex_res": [tex_h, tex_w]}, run / "texture.pt")
    cmap.save(run / "colormap.json")
    write_json(run / "split.json", split)
    attack_meta = {
        "mode": args.mode, "attacker_id": args.attacker_id, "victim": args.victim, "target": target,
        "checkpoint": args.checkpoint, "model": recognizer.load_report,
        "gallery": args.gallery, "gallery_per_id": args.max_gallery, "gallery_report": g_report,
        "identities": sorted(E), "frame_shape": shape_dict, "tex_res": [tex_h, tex_w],
        "dev_frac": args.dev_frac, "dev_mode": args.dev_mode, "no_eot": args.no_eot,
        "coverage_train": {"mean": float(np.mean(cover)), "min": float(np.min(cover)), "max": float(np.max(cover))},
        "prepare_report": p_report, "color_map_calibrated": cmap.calibrated,
        "final": log_rows[-1]}
    if args.frame_mask:
        attack_meta["frame_source"] = "photo"
        attack_meta["frame_mask"] = str(args.frame_mask)
        attack_meta["frame_lens"] = str(args.frame_lens) if args.frame_lens else None
        attack_meta["grow_px"] = float(args.grow_px)
        attack_meta["clearance_mm"] = float(args.clearance_mm)
        attack_meta["ipd_mm"] = float(args.ipd_mm)
    if args.extra_gallery:
        attack_meta["extra_gallery"] = extra_gallery_list
        attack_meta["extra_gallery_report"] = extra_gallery_report
        meta_file = run / "meta.json"
        if meta_file.exists():
            try:
                meta_json = json.loads(meta_file.read_text(encoding="utf-8"))
                meta_json["extra_gallery"] = extra_gallery_list
                write_json(meta_file, meta_json)
            except Exception:
                pass
    write_json(run / "attack.json", attack_meta)
    print(f"results: {run}")


if __name__ == "__main__":
    main()
